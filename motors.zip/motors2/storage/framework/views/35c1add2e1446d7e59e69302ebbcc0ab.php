<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>حقول الفئة: <?php echo e(App::getLocale() == 'ar' ? $category->name_ar : $category->name_en); ?></h2>

    <a href="<?php echo e(route('categories.fields.create', $category->id)); ?>" class="btn btn-primary mb-3">إضافة حقل جديد</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>اسم الحقل</th>
                <th>القيم</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $category->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e(App::getLocale() == 'ar' ? $field->field_ar : $field->field_en); ?>

                    </td>
                    <td>
                        <ul>
                            <?php $__currentLoopData = $field->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e(App::getLocale() == 'ar' ? $value->value_ar : $value->value_en); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                        <a href="<?php echo e(route('categories.fields.edit', [$category->id, $field->id])); ?>" class="btn btn-warning btn-sm">تعديل</a>
                        <form action="<?php echo e(route('categories.fields.destroy', [$category->id, $field->id])); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel10\motors2\resources\views/categories/fields/show.blade.php ENDPATH**/ ?>