<!-- Core JS -->
<script src="<?php echo e(asset('admin/assets/vendor/libs/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendor/libs/popper/popper.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendor/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendor/libs/node-waves/node-waves.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendor/libs/hammer/hammer.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/vendor/js/menu.js')); ?>"></script>

<!-- endbuild -->

<!-- Vendors JS -->

<!-- Main JS -->
<script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>
<?php /**PATH D:\xampp\htdocs\laravel10\motors2\resources\views/admin/includes/scripts.blade.php ENDPATH**/ ?>