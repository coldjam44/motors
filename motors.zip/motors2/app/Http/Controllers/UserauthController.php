<?php

namespace App\Http\Controllers;

use App\Models\userauth;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserauthController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    // public function register(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'first_name' => 'required|string|max:255',
    //         'last_name' => 'required|string|max:255',
    //         'email' => 'required|email|unique:userauths,email',
    //         'phone_number' => 'required|unique:userauths,phone_number',
    //         'password' => 'required|min:6|confirmed',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json(['errors' => $validator->errors()], 422);
    //     }

    //     $user = UserAuth::create([
    //         'first_name' => $request->first_name,
    //         'last_name' => $request->last_name,
    //         'email' => $request->email,
    //         'phone_number' => $request->phone_number,
    //         'password' => Hash::make($request->password),
    //     ]);

    //     // إنشاء توكن JWT
    //     $token = JWTAuth::fromUser($user);

    //     return response()->json([
    //         'message' => 'User registered successfully',
    //         'user' => $user,
    //         'token' => $token, // إرجاع التوكن للمستخدم
    //     ], 201);
    // }

    // public function login(Request $request)
    // {
    //     $credentials = $request->validate([
    //         'email' => 'required|email',
    //         'password' => 'required'
    //     ]);

    //     if (!$token = auth('api')->attempt($credentials)) {
    //         return response()->json(['message' => 'Invalid credentials'], 401);
    //     }

    //     return response()->json([
    //         'message' => 'Login successful',
    //         'token' => $token,
    //     ]);
    // }



    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:userauths,email',
            'phone_number' => 'required|unique:userauths,phone_number',
            'password' => 'required|min:6|confirmed',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $user = Userauth::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'phone_number' => $request->phone_number,
            'password' => Hash::make($request->password),
        ]);

        // إنشاء التوكن JWT
        $token = JWTAuth::fromUser($user);

        return response()->json([
            'message' => 'User registered successfully',
            'user' => $user,
            'token' => $token, // إرجاع التوكن للمستخدم
        ], 201);
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $user = Userauth::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        // إنشاء التوكن للمستخدم
        $token = JWTAuth::fromUser($user);

        return response()->json([
            'message' => 'Login successful',
            'token' => $token,
            'user' => $user,
        ]);
    }

    public function update(Request $request)
    {
        // الحصول على المستخدم الحالي من التوكن
        $user = auth()->user();

        // التحقق من صحة البيانات المدخلة
        $validator = Validator::make($request->all(), [
            'email' => 'sometimes|email|unique:userauths,email,' . $user->id,
            'phone_number' => 'sometimes|unique:userauths,phone_number,' . $user->id,
            'password' => 'sometimes|min:6|confirmed',
            'profile_image' => 'sometimes|image|mimes:jpeg,png,jpg,gif|max:2048',
            'cover_image' => 'sometimes|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // تحديث البيانات إن وُجدت في الطلب
        if ($request->has('email')) {
            $user->email = $request->email;
        }
        if ($request->has('phone_number')) {
            $user->phone_number = $request->phone_number;
        }
        if ($request->has('password')) {
            $user->password = Hash::make($request->password);
        }

        // تحديث الصورة الشخصية إذا وُجدت
        if ($request->hasFile('profile_image')) {
            // حذف الصورة القديمة إن وُجدت
            if ($user->profile_image && file_exists(public_path($user->profile_image))) {
                unlink(public_path($user->profile_image));
            }
            // حفظ الصورة الجديدة في مجلد public/profile_images
            $imageName = time() . '_profile.' . $request->file('profile_image')->getClientOriginalExtension();
            $request->file('profile_image')->move(public_path('profile_images'), $imageName);

            // حفظ الرابط المباشر في قاعدة البيانات
            $user->profile_image = url('profile_images/' . $imageName);
        }

        // تحديث صورة الغلاف إذا وُجدت
        if ($request->hasFile('cover_image')) {
            // حذف الصورة القديمة إن وُجدت
            if ($user->cover_image && file_exists(public_path($user->cover_image))) {
                unlink(public_path($user->cover_image));
            }
            // حفظ الصورة الجديدة في مجلد public/cover_images
            $imageName = time() . '_cover.' . $request->file('cover_image')->getClientOriginalExtension();
            $request->file('cover_image')->move(public_path('cover_images'), $imageName);

            // حفظ الرابط المباشر في قاعدة البيانات
            $user->cover_image = url('cover_images/' . $imageName);
        }


        // حفظ التعديلات
        $user->save();

        return response()->json([
            'message' => 'Profile updated successfully',
            'user' => $user
        ]);
    }


}
