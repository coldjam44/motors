<?php

namespace App\Http\Controllers;

use App\Models\category;
use Illuminate\Http\Request;
use App\Models\CategoryField;

class CategoryFieldController extends Controller
{
    public function create($id)
    {
        $category = category::findOrFail($id);
        return view('categories.fields.create', compact('category'));
    }

    public function store(Request $request, $id)
{
    $request->validate([
        'fields' => 'required|array',
    ]);

    foreach ($request->fields as $field) {
        if (!isset($field['field_ar'], $field['field_en'], $field['values_ar'], $field['values_en'])) {
            continue; // تأكد من أن كل البيانات موجودة
        }

        // إنشاء الحقل الرئيسي
        $categoryField = CategoryField::create([
            'category_id' => $id,
            'field_ar' => $field['field_ar'],
            'field_en' => $field['field_en'],
        ]);

        // حفظ القيم المرتبطة بهذا الحقل
        foreach ($field['values_ar'] as $index => $value_ar) {
            $value_en = $field['values_en'][$index] ?? ''; // القيمة الإنجليزية إذا لم يتم إدخالها
            $categoryField->values()->create([
                'value_ar' => $value_ar,
                'value_en' => $value_en,
            ]);
        }
    }

    return redirect()->route('categories.fields.create', $id)->with('success', 'تمت إضافة الحقول والقيم بنجاح!');
}

public function show($id)
{
    $category = Category::with('fields.values')->findOrFail($id);

    return view('categories.fields.show', compact('category'));
}

public function edit($id, $field_id)
{
    $category = Category::findOrFail($id);
    $field = CategoryField::with('values')->findOrFail($field_id);

    return view('categories.fields.edit', compact('category', 'field'));
}

public function update(Request $request, $id, $field_id)
{
    $request->validate([
        'field_ar' => 'required|string',
        'field_en' => 'required|string',
        'values_ar' => 'required|array',
        'values_en' => 'required|array',
    ]);

    $field = CategoryField::findOrFail($field_id);
    $field->update([
        'field_ar' => $request->field_ar,
        'field_en' => $request->field_en,
    ]);

    // حذف القيم القديمة وإضافة الجديدة
    $field->values()->delete();
    foreach ($request->values_ar as $index => $value_ar) {
        $value_en = $request->values_en[$index] ?? '';
        $field->values()->create([
            'value_ar' => $value_ar,
            'value_en' => $value_en,
        ]);
    }

    return redirect()->route('categories.fields.show', $id)->with('success', 'تم تحديث الحقل بنجاح!');
}

public function destroy($id, $field_id)
{
    $field = CategoryField::findOrFail($field_id);
    $field->delete();

    return redirect()->route('categories.fields.show', $id)->with('success', 'تم حذف الحقل بنجاح!');
}


}
