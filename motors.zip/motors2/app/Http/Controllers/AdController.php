<?php

namespace App\Http\Controllers;

use App\Models\Ad;
use Illuminate\Http\Request;

class AdController extends Controller
{
    public function index(Request $request)
{
    $query = Ad::with(['user', 'subImages', 'fieldValues.field', 'fieldValues.fieldValue'])
        ->orderBy('created_at', 'desc');

    if ($request->has('status') && $request->status != '') {
        $query->where('status', $request->status);
    }

    $ads = $query->get();

    return view('pages.ads.ads-management', compact('ads'));
}


public function updateStatus(Request $request, $id)
{
    $ad = Ad::findOrFail($id);

    // تحديث الحالة بناءً على الاختيار
    $ad->status = $request->status;
    $ad->save();

    return redirect()->back()->with('success', 'تم تحديث حالة الإعلان بنجاح');
}

public function destroy($id)
{
    $ad = Ad::findOrFail($id);

    // حذف الصور الفرعية المرتبطة
    foreach ($ad->subImages as $image) {
        $imagePath = public_path($image->image);
        if (file_exists($imagePath)) {
            unlink($imagePath); // حذف الصورة من السيرفر
        }
        $image->delete(); // حذف السجل من قاعدة البيانات
    }

    // حذف الصورة الرئيسية إذا كانت موجودة
    $mainImagePath = public_path($ad->main_image);
    if (file_exists($mainImagePath)) {
        unlink($mainImagePath);
    }

    // حذف القيم المرتبطة بالحقول
    $ad->fieldValues()->delete();

    // حذف الإعلان
    $ad->delete();

    return redirect()->back()->with('success', 'تم حذف الإعلان بنجاح');
}


}
