<?php

namespace App\Http\Controllers\Api;

use App\Models\Ad;
use App\Models\AdImage;
use App\Models\Favorite;
use App\Models\AdFieldValue;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AdController extends Controller
{



    public function store(Request $request)
    {
        // استرجاع المستخدم من التوكن
        $token = request()->bearerToken();
        if (!$token) {
            return response()->json(['message' => 'Token not provided'], 401);
        }

        try {
            $user = JWTAuth::parseToken()->authenticate();
        } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
            return response()->json(['message' => 'Token expired'], 401);
        } catch (\Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
            return response()->json(['message' => 'Invalid token'], 401);
        } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {
            return response()->json(['message' => 'Token absent'], 401);
        }

        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }


        // التحقق من البيانات المطلوبة
        $validator = Validator::make($request->all(), [
            'category_id' => 'required|exists:categories,id',
            'country_id' => 'required|exists:countries,id',
            'city_id' => 'required|exists:cities,id',
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'phone_number' => 'required|string|max:20', // التحقق من إدخال الهاتف
            'main_image' => 'required|image|max:2048',
            'sub_images.*' => 'image|max:2048',
            'fields' => 'required|array',
            'fields.*.category_field_id' => 'required|exists:category_fields,id',
            'fields.*.category_field_value_id' => 'required|exists:category_field_values,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // حفظ الصورة الرئيسية في `public/ads/`
        $mainImage = $request->file('main_image');
        $mainImageName = time() . '_' . $mainImage->getClientOriginalName();
        $mainImage->move(public_path('ads'), $mainImageName);
        $mainImagePath = 'ads/' . $mainImageName;

        // إنشاء الإعلان
        $ad = Ad::create([
            'user_id' => $user->id,
            'category_id' => $request->category_id,
            'country_id' => $request->country_id,
            'city_id' => $request->city_id,
            'title' => $request->title,
            'description' => $request->description,
            'price' => $request->price,
            'phone_number' => $request->phone_number,
            'status' => 'pending', // تعيين الحالة الافتراضية إلى pending
            'main_image' => $mainImagePath,
        ]);

        // حفظ الصور الفرعية في `public/ads/`
        if ($request->hasFile('sub_images')) {
            foreach ($request->file('sub_images') as $image) {
                $imageName = time() . '_' . $image->getClientOriginalName();
                $image->move(public_path('ads'), $imageName);
                AdImage::create(['ad_id' => $ad->id, 'image' => 'ads/' . $imageName]);
            }
        }

        // حفظ الحقول المرتبطة
        foreach ($request->fields as $field) {
            AdFieldValue::create([
                'ad_id' => $ad->id,
                'category_field_id' => $field['category_field_id'],
                'category_field_value_id' => $field['category_field_value_id'],
            ]);
        }

        return response()->json(['message' => 'Ad created successfully', 'ad' => $ad], 201);
    }
    public function index()
    {
        $user = auth('api')->user();

        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        // جلب الإعلانات الخاصة بالمستخدم فقط
        $ads = Ad::with(['subImages', 'fieldValues'])
            ->where('user_id', $user->id) // ✅ عرض الإعلانات الخاصة بالمستخدم فقط
            ->get();

        $ads->transform(function ($ad) {
            // عرض الصورة الرئيسية كرابط مباشر
            $ad->main_image = $ad->main_image ? url($ad->main_image) : null;

            // عرض الصور الفرعية كرابط مباشر
            $ad->subImages->transform(function ($image) {
                $image->image = url($image->image);
                return $image;
            });

            // إحضار الحقول المرتبطة بالإعلان
            $ad->fieldValues->transform(function ($fieldValue) {
                return [
                    'category_field_id' => $fieldValue->category_field_id,
                    'category_field_value_id' => $fieldValue->category_field_value_id,
                ];
            });

            return [
                'id' => $ad->id,
                'user_id' => $ad->user_id, // ✅ عرض معرف المستخدم

                'title' => $ad->title,
                'description' => $ad->description,
                'price' => $ad->price,
                'phone_number' => $ad->phone_number,
                'status' => $ad->status, // عرض الحالة
                'main_image' => $ad->main_image,
                'sub_images' => $ad->subImages,
                'field_values' => $ad->fieldValues,
            ];
        });

        return response()->json(['ads' => $ads]);
    }

    public function destroy($id)
    {
        // استرجاع المستخدم من التوكن
        try {
            $user = JWTAuth::parseToken()->authenticate();
        } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        // البحث عن الإعلان
        $ad = Ad::with('subImages')->where('id', $id)->where('user_id', $user->id)->first();

        if (!$ad) {
            return response()->json(['message' => 'Ad not found or unauthorized'], 404);
        }

        // حذف الصورة الرئيسية من السيرفر
        if ($ad->main_image && file_exists(public_path($ad->main_image))) {
            unlink(public_path($ad->main_image));
        }

        // حذف الصور الفرعية من السيرفر
        foreach ($ad->subImages as $image) {
            if (file_exists(public_path($image->image))) {
                unlink(public_path($image->image));
            }
            $image->delete();
        }

        // حذف الحقول المرتبطة
        AdFieldValue::where('ad_id', $ad->id)->delete();

        // حذف الإعلان
        $ad->delete();

        return response()->json(['message' => 'Ad deleted successfully'], 200);
    }




    // public function indexadsusers()
    // {
    //     $ads = Ad::with(['subImages', 'fieldValues'])->get();

    //     $ads->transform(function ($ad) {
    //         // عرض الصورة الرئيسية كرابط مباشر
    //         $ad->main_image = $ad->main_image ? url($ad->main_image) : null;

    //         // عرض الصور الفرعية كرابط مباشر
    //         $ad->subImages->transform(function ($image) {
    //             $image->image = url($image->image);
    //             return $image;
    //         });

    //         // إحضار الحقول المرتبطة بالإعلان
    //         $ad->fieldValues->transform(function ($fieldValue) {
    //             return [
    //                 'category_field_id' => $fieldValue->category_field_id,
    //                 'category_field_value_id' => $fieldValue->category_field_value_id,
    //             ];
    //         });

    //         return [
    //             'id' => $ad->id,
    //             'user_id' => $ad->user_id, // ✅ عرض معرف المستخدم
    //             'title' => $ad->title,
    //             'description' => $ad->description,
    //             'price' => $ad->price,
    //             'phone_number' => $ad->phone_number,
    //             'status' => $ad->status, // ✅ عرض الحالة
    //             'main_image' => $ad->main_image,
    //             'sub_images' => $ad->subImages,
    //             'field_values' => $ad->fieldValues,
    //         ];
    //     });

    //     return response()->json(['ads' => $ads]);
    // }


    public function indexadsusers(Request $request)
    {
        $query = Ad::with(['subImages', 'fieldValues']);

        // تطبيق الفلاتر الأساسية
        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->has('country_id')) {
            $query->where('country_id', $request->country_id);
        }
        if ($request->has('city_id')) {
            $query->where('city_id', $request->city_id);
        }

        if ($request->has('min_price')) {
            $query->where('price', '>=', $request->min_price);
        }
        if ($request->has('max_price')) {
            $query->where('price', '<=', $request->max_price);
        }


        // **فلترة حسب الحقول والقيم**
        if ($request->has('fields')) {
            $fields = $request->input('fields'); // استلام الحقول والقيم كـ array

            $query->whereHas('fieldValues', function ($q) use ($fields) {
                foreach ($fields as $fieldId => $valueId) {
                    $q->where('category_field_id', $fieldId)
                      ->where('category_field_value_id', $valueId);
                }
            });
        }

        // تنفيذ الاستعلام وجلب النتائج
        $ads = $query->get();

        // تحويل البيانات
        $ads->transform(function ($ad) {
            $ad->main_image = $ad->main_image ? url($ad->main_image) : null;

            $ad->subImages->transform(function ($image) {
                $image->image = url($image->image);
                return $image;
            });

            $ad->fieldValues->transform(function ($fieldValue) {
                return [
                    'category_field_id' => $fieldValue->category_field_id,
                    'category_field_value_id' => $fieldValue->category_field_value_id,
                ];
            });

            return [
                'id' => $ad->id,
                'user_id' => $ad->user_id,
                'title' => $ad->title,
                'description' => $ad->description,
                'price' => $ad->price,
                'phone_number' => $ad->phone_number,
                'status' => $ad->status,
                'main_image' => $ad->main_image,
                'sub_images' => $ad->subImages,
                'field_values' => $ad->fieldValues,
            ];
        });

        return response()->json(['ads' => $ads]);
    }


    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:pending,approved,rejected',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $ad = Ad::find($id);
        if (!$ad) {
            return response()->json(['message' => 'Ad not found'], 404);
        }

        $ad->update(['status' => $request->status]);

        return response()->json(['message' => 'Ad status updated successfully', 'ad' => $ad], 200);
    }


    public function toggleFavorite(Request $request)
{
    $user = JWTAuth::parseToken()->authenticate();

    if (!$user) {
        return response()->json(['message' => 'Unauthorized'], 401);
    }

    $request->validate([
        'ad_id' => 'required|exists:ads,id',
    ]);

    $favorite = Favorite::where('user_id', $user->id)
                        ->where('ad_id', $request->ad_id)
                        ->first();

    if ($favorite) {
        // إزالة الإعلان من المفضلة
        $favorite->delete();
        return response()->json(['message' => 'Ad removed from favorites']);
    } else {
        // إضافة الإعلان إلى المفضلة
        Favorite::create([
            'user_id' => $user->id,
            'ad_id' => $request->ad_id,
        ]);
        return response()->json(['message' => 'Ad added to favorites']);
    }
}


public function getFavorites()
{
    $user = JWTAuth::parseToken()->authenticate();

    if (!$user) {
        return response()->json(['message' => 'Unauthorized'], 401);
    }

    $favorites = Favorite::with('ad.subImages', 'ad.fieldValues')
                         ->where('user_id', $user->id)
                         ->get()
                         ->map(function ($favorite) {
                             $ad = $favorite->ad;
                             $ad->main_image = $ad->main_image ? url($ad->main_image) : null;

                             // تعديل الصور الفرعية
                             $ad->subImages->transform(function ($image) {
                                 $image->image = url($image->image);
                                 return $image;
                             });

                             // تعديل الحقول المرتبطة
                             $ad->fieldValues->transform(function ($fieldValue) {
                                 return [
                                     'category_field_id' => $fieldValue->category_field_id,
                                     'category_field_value_id' => $fieldValue->category_field_value_id,
                                 ];
                             });

                             return $ad;
                         });

    return response()->json(['favorites' => $favorites]);
}


}
