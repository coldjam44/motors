<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ad extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id', 'category_id', 'country_id', 'city_id',
        'title', 'description', 'price', 'main_image','phone_number', 'status'
    ];

    public function user()
    {
        return $this->belongsTo(UserAuth::class, 'user_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function images()
    {
        return $this->hasMany(AdImage::class);
    }

    public function fieldValues()
    {
        return $this->hasMany(AdFieldValue::class);
    }

    public function subImages()
    {
        return $this->hasMany(AdImage::class, 'ad_id');
    }

}
