@extends('admin.layouts.app')


@section('content')
<h4 class="py-3 mb-4">Page 1</h4>
<p>
  Sample page.<br />For more layout options use
  <a href="" target="_blank" class="fw-medium">HTML starter template generator</a> and refer
  <a
    href="https://demos.pixinvent.com/vuexy-html-admin-template/documentation//layouts.html"
    target="_blank"
    class="fw-medium"
    >Layout docs</a
  >.
</p>
@endsection
