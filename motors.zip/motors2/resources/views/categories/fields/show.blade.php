@extends('admin.layouts.app')

@section('content')
<div class="container">
    <h2>حقول الفئة: {{ App::getLocale() == 'ar' ? $category->name_ar : $category->name_en }}</h2>

    <a href="{{ route('categories.fields.create', $category->id) }}" class="btn btn-primary mb-3">إضافة حقل جديد</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>اسم الحقل</th>
                <th>القيم</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            @foreach($category->fields as $field)
                <tr>
                    <td>
                        {{ App::getLocale() == 'ar' ? $field->field_ar : $field->field_en }}
                    </td>
                    <td>
                        <ul>
                            @foreach($field->values as $value)
                                <li>{{ App::getLocale() == 'ar' ? $value->value_ar : $value->value_en }}</li>
                            @endforeach
                        </ul>
                    </td>
                    <td>
                        <a href="{{ route('categories.fields.edit', [$category->id, $field->id]) }}" class="btn btn-warning btn-sm">تعديل</a>
                        <form action="{{ route('categories.fields.destroy', [$category->id, $field->id]) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
