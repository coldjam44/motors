<?php

return [

    'title_page' => 'Classes',
    'List_classes' => 'List Classes',
    'add_class' => 'add class',
    'edit_class'=> 'تعديل صف',
    'delete_class'=> 'حذف صف',
    'Warning_Grade'=> 'هل انت متاكد من عملية الحذف ؟',
    'submit' => 'submit',
    'title'=>'title in arabic',
    'titleenglish'=>'title',
    'Name_Grade'=>'Name Grade',
    'add_row'=>'add row',
    'delete_row'=>'Delete row',
    'Processes'=>'Processes',
    'Edit'=>'Edit',
    'Delete'=>'Delete',
    'Close' => 'Close',
    'delete_checkbox'=> 'Delete Selected',
    'Search_By_Grade'=> 'Search By Grade Name',



];
