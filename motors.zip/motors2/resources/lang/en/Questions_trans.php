
<?php

return[
'title_page'=>'title_page',
'List_Grades'=>'List_Questions',
'add_Grade'=>'Add',
'edit_Grade'=>'edit_Questions',
'delete_Grade'=>'delete_Questions',
'Warning_Grade'=>'Warning_Questions',
'stage_name_ar'=>'title_ar',
'stage_name_en'=>'title_en',
'stage_body_ar'=>'body_ar',
'stage_body_en'=>'body_en',
'body'=>'body',
'Submit'=>'Submit',
'title'=>'title',
'Processes'=>'Processes',
'Edit'=>'Edit',
'Delete'=>'Delete',
'Close'=>'Close',
'delete_Grade_Error'=>'The Grade cannot be deleted because there are classes attached to it',
'delete_checkbox'=> 'Delete Selected',


];
