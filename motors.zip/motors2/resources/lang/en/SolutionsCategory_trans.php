
<?php

return[
'title_page'=>'title_page',
'List_Grades'=>'List_Grades',
'add_Grade'=>'Add',
'edit_Grade'=>'edit_Grade',
'delete_Grade'=>'delete_Grade',
'Warning_Grade'=>'Warning_Grade',
'stage_name_ar'=>'title_ar',
'stage_name_en'=>'title_en',
'Value'=>'value',
'Submit'=>'Submit',
'Name'=>'title',
'Processes'=>'Processes',
'Edit'=>'Edit',
'Delete'=>'Delete',
'Close'=>'Close',
'delete_Grade_Error'=>'The Grade cannot be deleted because there are classes attached to it',
'delete_checkbox'=> 'Delete Selected',


];
