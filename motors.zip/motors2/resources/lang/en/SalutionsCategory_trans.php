
<?php

return[
'title_page'=>'title_page',
'List_Grades'=>'List_Questions',
'add_Grade'=>'Add',
'edit_Grade'=>'edit',
'delete_Grade'=>'delete',
'Warning_Grade'=>'Warning',
'stage_name_ar'=>'Name_ar',
'stage_name_en'=>'Name_en',

'body'=>'body',
'Submit'=>'Submit',
'Name'=>'Name',
'Processes'=>'Processes',
'Edit'=>'Edit',
'Delete'=>'Delete',
'Close'=>'Close',
'delete_Grade_Error'=>'The Grade cannot be deleted because there are classes attached to it',
'delete_checkbox'=> 'Delete Selected',


];
