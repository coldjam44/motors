<?php

return [

    'Dashboard'=>'الرئيسية',
    'Dashboard_page'=>'لوحة التحكم',
    'Main_title'=>'برنامج مورا سوفت لادارة المدارس',
    'Programname' => 'الرئيسية',
    'change_language'=>'تغير اللغة',
    'Grades'=>' العداد',
    'counter'=>' العداد',
    'category'=>'المنتجات',
    'amenity'=>'الخدمات والمرافق',
    'Article Category'=>'فئة المنتجات',
    'Article Reason'=>'قائمة الاقسام الدراسية',
    'ChangePassword'=>'تغير كلمة المرور',
'contact'=>'التواصل معنا',


'term'=>'سياسة الخصوصية ',





    'banners'=>'البانر',
    'categorys'=>'التصنيفات',
    'country'=>'الدول',
    'countrys'=>'الدول',
    'city'=>'المدن',
    'citys'=>'المدن',
    'ads'=>'الاعلانات',
    'users'=>'المستخدمين',
    'admins'=>'الادمن',

    'banners'=> 'البانر',
     'categorys'=> 'categories',
     'country'=> 'countries',
     'countrys'=> 'countries',
     'city'=> 'cities',
     'citys'=> 'cities',




    'Question'=>'اسئلة',
    'feature'=>'ميزات',
    'features'=>'ميزات',
    'reviews'=>'مراجعة الاوتيل',
    'avilablerooms'=>'الغرف المتاحة',
    'promocodes'=>'كوبونات الخصم',
    'hotels'=>'الفنادق',
    'ramadanoffers'=>'العروض الرمضانية',
    'amenitys'=>'الخدمات والمرافق',
    'findstays'=>'الحصول على الاقامة',
    'family_insurance'=>'تأمين الاسر',
    'individual_insurance'=>'تأمين الافراد',
    'place'=>'مكان',
    'hospital'=>'المستشفى',
    'subscribe'=>'الاشتراك',
    'aboutus'=>'عننا',
    'medicalauthorities'=>'الجهات الطبية',
    'customerreview'=>'اراء العملاء',
    'insurancetype'=>'انواع التأمين',
    'technology'=>'تقنية',
    'support'=>'الدعم',
    'anothercard'=>'البطاقة الاخرى',
    'ArticleReason'=>'سبب المقال',
    'solution'=>'الحلول',
    'article'=>'المقالة',
    'team'=>'الفريق',
    'ourworks'=>'عملنا',
    'ourwork'=>'عملنا',
    'category'=>'المنتجات',
    'articalecategory'=>'فئة المنتجات',
    'socialmedia'=>'التواصل الاجتماعي',

    'Testimonial'=>'دليل',
    'search'=>'بحث',
    'position'=>'موضع',
    'notification'=>'الاشعارات',

    'addPhotoInHomescreen'=>'اضافة صورة في الصفحة الرئيسية',
    'companydata'=>'بيانات الشركة',




    'Article Reason'=>'سبب المقال',
    'Article'=>'المقال',
    'SolutionsCategory'=>'فئة الحلول',
    'Team'=>' الفريق',
    'logout'=>' الخروج',
    'List_Parents'=>'قائمة اولياء الامور',
    'Our Work'=>'أعمالنا',
    'Social Media'=>'وسائل التواصل الاجتماعي',
    'Solutions Category'=>'فئة الحلول',
    'Solutions'=>'الحلول',
    'Support'=>'الدعم',
    'Questions'=>' أسئلة',
    'Settings'=>'الاعدادات',
    'Users'=>'المستخدمين',
    'Copyright' => 'جميع الحقوق محفوظة ',
    'Name_Programer' => 'سمير جمال مورا سوفت',

    'client' => 'العملاء',
    'projects' => 'المشاريع',
    'years of experience' => 'سنوات الخبرة',
    'Followers'=> 'المتابعين',


];
