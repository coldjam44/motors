
<?php

return[

 'title_page' => 'المراحل الدراسية',
 'List_Grades' => 'قائمة المراحل الدراسية',
 'add_Grade' => 'اضافة ',
 'edit_Grade' => 'تعديل ',
 'delete_Grade' => 'حذف ',
 'Warning_Grade' => 'هل انت متاكد من عملية الحذف ؟',
 'stage_name_ar' => 'العنوان بالعربية',
 'stage_name_en' => 'العنوان بالانجليزية',
 
 'body' => 'النص',
 'Submit' => 'حفظ البيانات',
 'Name' => ' العنوان',
 'Processes' => 'العمليات',
 'Edit' => 'تعديل',
 'Delete' => 'حذف',
 'Close' => 'اغلاق',
 'delete_Grade_Error'=>'لايمكن حذف المرحلة بسبب وجود صفوف تابعة لها',


];
