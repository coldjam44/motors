<?php

return [

  'title_page' => 'الصفوف الدراسية',
  'List_classes' => 'قائمة الصفوف الدراسية',
  'add_class' => 'اضافة صف',
  'edit_class'=> 'تعديل صف',
  'delete_class'=> 'حذف صف',
  'Warning_class'=> 'هل انت متاكد من عملية الحذف ؟',
  'stage_name_ar' => 'اسم الصف بالعربية',
  'stage_name_en' => 'اسم الصف بالانجليزية',
  'submit' => 'حفظ البيانات',
  'title'=>' العنوان بالعربية',
  'title'=>'  العنوان بالانجلزية',
  'Name_Grade'=>'اسم المرحلة',
  'add_row'=>'ادراج سجل',
  'delete_row'=>'حذف',
  'Processes'=>'العمليات',
  'Edit'=>'تعديل',
  'Delete'=>'حذف',
  'Close' => 'اغلاق',
  'delete_checkbox'=> 'حذف الصفوف المختارة',
  'Search_By_Grade'=> 'بحث باسم المرحلة',

];
